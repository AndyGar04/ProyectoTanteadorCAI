/* NoaiscaNeopixelDisplay
   Simulating a Seven Segment Display with Neopixels
   
   Download from: http://werner.rothschopf.net/202005_arduino_neopixel_display.htm

   open tasks
   - 
   
   copyright 2021 noiasca noiasca@yahoo.com
   
   Version
   2020-03-02 first version: https://forum.arduino.cc/index.php?topic=668096.0
   2020-05-01 multiple pixel per segment idea: https://forum.arduino.cc/index.php?topic=681417
   2020-05-02 reference to external created strip object (with inputs from https://forum.arduino.cc/index.php?topic=681647.0) 
              multiple displays on one strip
   2020-05-03 migration to segmentArray in user sketch, 
   2020-05-04 callback function for additional pixels
   2021-05-24 1.0.1 fixed lowLevelWrite to leftshift according segsize
   
*/

#pragma once
#define NOIASCA_NEOPIXEL_DISPLAY_VERSION "NoiascaNeopixelDisplay 1.0.1"   // this library

#define NEOPIXEL_DISPLAY_CHARSET_SIZE 2          // 2 full charset (default), 1 capital letters, 0 numbers and some symbols only
#define NEOPIXEL_DISPLAY_DEBUG 0                 // Library debug messages: 0 off (default);   1 important/error;   2 warning;   3 info/debug;

//#if defined(__AVR__)
//#include <avr/pgmspace.h>
//#elif defined(ESP8266)
//#include <pgmspace.h>
//#endif

#include <Adafruit_NeoPixel.h>                                       // install library from Library manager

/*
   Segments are named and orded like this

          SEG_A
   SEG_F         SEG_B
          SEG_G
   SEG_E         SEG_C
          SEG_D             SEG_DP

          
  The mapping which pixels will be lighted for which character is basically done in 3 steps

  Step 1 
  
  The user has to assign the pixels to each segment in the user Sketch
  example: 
  
typedef uint32_t segsize_t;
const segsize_t segment[8] { 
  0b0000000000000011,  // SEG_A
  0b0000000000001100,  // SEG_B
  0b0000000000110000,  // SEG_C
  0b0000000011000000,  // SEG_D
  0b0000001100000000,  // SEG_E
  0b0000110000000000,  // SEG_F
  0b0011000000000000,  // SEG_G
  0b1100000000000000   // SEG_DP
};

 Step 2 
 the library has a character table to map characters to the needed segments
 
 Step 3
 The write method combines the users segment definition with the character segments to optain 
 a pixel bitmap to be printed to the display
*/

/* *******************************************************************
         character set for 7 segment displays
 * ******************************************************************/

// each segment is assigned to one of 8 positions (bitwise)

const byte SEG_A  = 1;
const byte SEG_B  = 2;
const byte SEG_C  = 4;
const byte SEG_D  = 8;
const byte SEG_E  = 16;
const byte SEG_F  = 32;
const byte SEG_G  = 64;
const byte SEG_DP = 128;

// several segments combined is one character
// The bitmap of the segment table only defines which segments belongs to which character

const static byte charTable [] PROGMEM  = {           // if you run out of FLASH memory and you only need numbers, you can delete the characters after 57
  0,                                                       //     32   space
  SEG_B | SEG_C | SEG_DP,                                  // !   33
  SEG_B | SEG_F,                                           // "   34
  0,                                                       // #   35
  SEG_A | SEG_C | SEG_D | SEG_F | SEG_G,                   // $   36
  SEG_A | SEG_B | SEG_F | SEG_G,                           // %   37
  0,                                                       // &   38
  SEG_B,                                                   // '   39
  SEG_A | SEG_D | SEG_E | SEG_F,                           // (   40
  SEG_A | SEG_B | SEG_C | SEG_D,                           // )   41
  0,                                                       // *   42   no character on 7segment
  0,                                                       // +   43   no character on 7segment
  0,                                                       // ,   44   will be handled in the write methode
  SEG_G,                                                   // -   45
  0,                                                       // .   46   will be handled in the write methode
  SEG_B | SEG_E | SEG_G ,                                  // /   47
  SEG_A | SEG_B | SEG_C | SEG_D | SEG_E | SEG_F,           // 0   48
  SEG_B | SEG_C,                                           // 1   49
  SEG_A | SEG_B | SEG_D | SEG_E | SEG_G,                   // 2   50
  SEG_A | SEG_B | SEG_C | SEG_D | SEG_G,                   // 3   51
  SEG_B | SEG_C | SEG_F | SEG_G,                           // 4   52
  SEG_A | SEG_C | SEG_D | SEG_F | SEG_G,                   // 5   53
  SEG_A | SEG_C | SEG_D | SEG_E | SEG_F | SEG_G,           // 6   54
  SEG_A | SEG_B | SEG_C,                                   // 7   55
  SEG_A | SEG_B | SEG_C | SEG_D | SEG_E | SEG_F | SEG_G,   // 8   56
  SEG_A | SEG_B | SEG_C | SEG_D | SEG_F | SEG_G,           // 9   57
#if NEOPIXEL_DISPLAY_CHARSET_SIZE >= 1
  0,                                                       // :   58   could be handled in the write methode
  0,                                                       // ;   59   could be handled in the write methode
  SEG_D | SEG_E | SEG_G,                                   // <   60
  SEG_G,                                                   // =   61
  SEG_C | SEG_D | SEG_G,                                   // >   62
  SEG_A | SEG_B | SEG_E | SEG_G,                           // ?   63
  0,                                                       // @   64
  SEG_A | SEG_B | SEG_C | SEG_E | SEG_F | SEG_G,           // A   65
  SEG_C | SEG_D | SEG_E | SEG_F | SEG_G,                   // B
  SEG_A | SEG_D | SEG_E | SEG_F,                           // C
  SEG_B | SEG_C | SEG_D | SEG_E | SEG_G,                   // D
  SEG_A | SEG_D | SEG_E | SEG_F | SEG_G,                   // E
  SEG_A | SEG_E | SEG_F | SEG_G,                           // F
  SEG_A | SEG_C | SEG_D | SEG_E | SEG_F,                   // G
  SEG_B | SEG_C | SEG_E | SEG_F | SEG_G,                   // H
  SEG_B | SEG_C,                                           // I
  SEG_B | SEG_C | SEG_D | SEG_E,                           // J
  SEG_A | SEG_C | SEG_E | SEG_F | SEG_G,                   // K
  SEG_D | SEG_E | SEG_F,                                   // L
  SEG_A | SEG_C | SEG_E,                                   // M
  SEG_C | SEG_E | SEG_G,                                   // N
  SEG_C | SEG_D | SEG_E | SEG_G,                           // O
  SEG_A | SEG_B | SEG_E | SEG_F | SEG_G,                   // P
  SEG_A | SEG_B | SEG_C | SEG_F | SEG_G,                   // Q
  SEG_E | SEG_G,                                           // R
  SEG_A | SEG_C | SEG_D | SEG_F | SEG_G,                   // S
  SEG_D | SEG_E | SEG_F | SEG_G,                           // T
  SEG_B | SEG_C | SEG_D | SEG_E | SEG_F,                   // U
  SEG_C | SEG_D | SEG_E,                                   // V
  SEG_B | SEG_D | SEG_F,                                   // W
  SEG_B | SEG_C | SEG_E | SEG_F | SEG_G,                   // X
  SEG_B | SEG_C | SEG_D | SEG_F | SEG_G,                   // Y
  SEG_A | SEG_B | SEG_D | SEG_E | SEG_G,                   // Z   90
  SEG_A | SEG_D | SEG_E | SEG_F,                           // [   91
  SEG_C | SEG_F | SEG_G,                                   /* \   92 backslash*/
  SEG_A | SEG_B | SEG_C | SEG_D,                           // ]   93
  SEG_A,                                                   // ^   94
  SEG_D,                                                   // _   95 underscore
  SEG_B,                                                   // `   96
#endif
#if NEOPIXEL_DISPLAY_CHARSET_SIZE >= 2
  SEG_C | SEG_D | SEG_E | SEG_G | SEG_DP,                  // a   97
  SEG_C | SEG_D | SEG_E | SEG_F | SEG_G,                   // b   98
  SEG_D | SEG_E | SEG_G,                                   // c   99
  SEG_B | SEG_C | SEG_D | SEG_E | SEG_G,                   // d   100
  SEG_A | SEG_D | SEG_E | SEG_F | SEG_G,                   // e   101
  SEG_A | SEG_E | SEG_F | SEG_G,                           // f   102
  SEG_A | SEG_C | SEG_D | SEG_E | SEG_F,                   // g G 103 capital letter will be used
  SEG_B | SEG_C | SEG_E | SEG_F | SEG_G,                   // h   104
  SEG_C,                                                   // i   105
  SEG_C | SEG_D,                                           // j   106
  SEG_A | SEG_C | SEG_E | SEG_F | SEG_G,                   // k   107
  SEG_E | SEG_F,                                           // l   108
  SEG_A | SEG_C | SEG_E,                                   // m n 109 n will be used
  SEG_C | SEG_E | SEG_G,                                   // n   110
  SEG_C | SEG_D | SEG_E | SEG_G,                           // o   111
  SEG_A | SEG_B | SEG_E | SEG_F | SEG_G,                   // p P 112
  SEG_A | SEG_B | SEG_C | SEG_D | SEG_F | SEG_DP,          // q Q 113
  SEG_E | SEG_G,                                           // r   114
  SEG_A | SEG_C | SEG_D | SEG_F | SEG_G,                   // s S 115
  SEG_D | SEG_E | SEG_F | SEG_G,                           // t   116
  SEG_C | SEG_D | SEG_E,                                   // u   117
  SEG_C | SEG_D | SEG_E,                                   // v u 118 u will be used
  SEG_C | SEG_D | SEG_E,                                   // w u 119 u will be used
  SEG_B | SEG_C | SEG_E | SEG_F | SEG_G,                   // x   120
  SEG_B | SEG_C | SEG_D | SEG_F | SEG_G,                   // y Y 121
  SEG_A | SEG_B | SEG_D | SEG_E | SEG_G,                   // z Z 122
  SEG_A | SEG_D | SEG_E | SEG_F,                           // {   123
  SEG_B | SEG_C,                                           // |   124
  SEG_A | SEG_B | SEG_C | SEG_D,                           // }   125
  SEG_G,                                                   // ~   126
  SEG_A | SEG_B | SEG_C | SEG_D | SEG_E | SEG_F | SEG_G | SEG_DP  //   127 all segments
#endif
};

const byte lastCharacter = sizeof(charTable)/sizeof(charTable[0]) + 32 - 1;  // if you use the full charset the lastCharacter will be 127

/* *******************************************************************
         base class
 * ******************************************************************/

class Noiasca_NeopixelDisplay : public Print {
  private:
    Adafruit_NeoPixel& strip;
    const uint16_t startPixel;                             // the first pixel to be used for this display
    const segsize_t *segment;  
    const byte numDigits;                                  // digits per device
    const byte pixelPerDigit;                              // all Pixel,  include double point pixels if they are available at each digit
    //const byte segPerDigit = 7;                            // How many segments per digit (not implemented, has to be 7)
    const byte addPixels;                                  // unregular additional pixels to be added to the strip
    using CallBack = int (*)(uint16_t value);
    CallBack funcPtr;
    const uint16_t ledCount;                               // How many NeoPixels are attached to the Arduino inkluding additional digits
  
    uint16_t currentPosition;                              // current position of cursor, the positions are order from LEFT (0) to RIGHT (highest)
    uint16_t lastPosition;                                 // last position of cursor - needed for dot and comma
    uint32_t colorFont = 0xFF0000;                         // default color of visible segment
    uint32_t colorBack = 0x000000;                         // default background color 0=black
    //segsize_t lastBitmap;                                // stores the last printed segments - for future use
    int8_t order = 1;                                      // leftToRight = 1, rightToLeft=-1

  public:
    // 4 parameters
    Noiasca_NeopixelDisplay(Adafruit_NeoPixel& strip, const segsize_t segment[8], byte numDigits, byte pixelPerDigit):
      strip(strip),
      startPixel(0),  
      segment{segment},
      numDigits(numDigits),
      pixelPerDigit(pixelPerDigit),
      addPixels(0),
      funcPtr(nullptr),
      ledCount(pixelPerDigit * numDigits + addPixels)
    {}
    
    // 5
    Noiasca_NeopixelDisplay(Adafruit_NeoPixel& strip, const segsize_t segment[8], byte numDigits, byte pixelPerDigit, uint16_t startPixel):
      strip(strip),
      startPixel(startPixel),
      segment{segment},
      numDigits(numDigits),
      pixelPerDigit(pixelPerDigit),
      addPixels(0),
      funcPtr(nullptr),
      ledCount(pixelPerDigit * numDigits + addPixels)
    {}
    
    // 6 od 7 parameter
    Noiasca_NeopixelDisplay(Adafruit_NeoPixel& strip, const segsize_t segment[8], byte numDigits, byte pixelPerDigit, uint16_t startPixel, byte addPixels, CallBack funcPtr):
      strip(strip),
      startPixel(startPixel),
      segment{segment},
      numDigits(numDigits),
      pixelPerDigit(pixelPerDigit),
      addPixels(addPixels),
      funcPtr(funcPtr),
      
      ledCount(pixelPerDigit * numDigits + addPixels)
    {}
 
/*!
  @brief   clear all pixels of the NeoPixel display.
  @note    this method uses Adafruits fill method to clear the definied  
           pixels of the display. Clearing is done by overwriting
           all pixels (startPixel to length) with the current background color.
*/
    void clear()                       
    {
      //strip.clear();                 // library clear uses the fill method
      strip.fill(colorBack, startPixel, ledCount);
      currentPosition = 0;
    }
    
/*!
  @brief   sets the background color
  @param   newColor  the new color
  @note    The background color is used if a pixel is not definied in a bitmap.
*/
    void setColorBack(uint32_t newColor)
    {
      colorBack = newColor;
    }
    
/*!
  @brief   sets the font color
  @param   newColor   the new color.
  @note    The font color is used if a pixel is definied in the bitmap.
*/    
    void setColorFont(uint32_t newColor)
    {
      colorFont = newColor;
    }
    
/*!
  @brief   sets cursor to the specifed cursor
  @param   newPosition   the new cursor position for the display
  @note    The order of cursor positions is from LEFT to RIGHT, starting with 0 on the LEFT.
*/        
    void setCursor(uint8_t newPosition)
    {
      currentPosition = newPosition;
    }

    void setPixelColor(uint16_t n, uint32_t c)
    {
      strip.setPixelColor(n, c);
    }
    
/*!
  @brief   reverses the pixels from 
  @note    if the pixels are wired from RIGHT to LEFT 
           use this command to reverse the display
*/  
    void setRightToLeft()
    {
       order = -1;
    }

/*!
  @brief   show the current buffer on the display         
  @note    simple passthrough method to Neopixel strip
*/     
    void show()
    {
      strip.show();
    }

/*!
  @brief   write a bitmap to the display 
  @param   position the position where the bitmap should be printed
           bitmask  the bitmask to be printed
           addOnly  if set to true, the bitmap will be added to the position          
  @note    if the pixels are wired from RIGHT to LEFT 
           use this command to reverse the display
*/      
    void writeLowLevel(uint8_t position, segsize_t bitmask, bool addOnly = false) {        // Ausgabe einer Bitmask an eine bestimmte Stelle
      byte offset = 0;
      if (order == 1)  // ascending order of digits
      {
        offset = position * pixelPerDigit + startPixel;              // pixel offset = first pixel of this digit
        if (funcPtr)                                                 // only if available (adress doesn't point to NULL)
          offset = offset + funcPtr(position);                       // the user can define his own ruleset for offset calculation due to additional pixels
      }
      else             // descending order of digits
      {
        uint16_t additional = 0;
        if (funcPtr)
          additional = funcPtr(position);
        offset = ledCount - pixelPerDigit - position * pixelPerDigit - additional + startPixel;
       }
#if NEOPIXEL_DISPLAY_DEBUG >= 3
      Serial.print("p="); 
      Serial.print(position);
      Serial.print(" o=");
      Serial.print(offset);
      Serial.print(" ");
      Serial.println(bitmask, BIN);
#endif
      for (byte i = 0; i < pixelPerDigit; i++)
      {
        if (bitmask & ((segsize_t)1 << i))                           // was if (bitmask & (1UL << i)) till 1.0.0
          strip.setPixelColor(i + offset, colorFont);
        else
          if (!addOnly) strip.setPixelColor(i + offset, colorBack);
      }
    }

    size_t write(uint8_t value)
    {
      if (value == '.' || value == ',')
      {
         writeLowLevel(lastPosition, segment[7], true);              // add decimal point to the last printed digit
      }
      else if (value > 31 && value <= lastCharacter)                 // write printable ASCII characters to display
      {
        segsize_t currentBitmap = 0;                                 // the current bitmap
        byte segments = 0;                                           // all segments for this character
        segments = pgm_read_byte_near(charTable + value - 32);       // the table starts with the first printable character at 32
        // step 3: combine the segmentCharacterMapping with the pixels from the users pixelSegmentMapping
        for (byte i = 0; i < 8; i++)
        {
          if (segments & (1UL << i))                                 // UL not necessary, but uses less Flash than if you leave it away
            currentBitmap |= segment[i];
        }
        writeLowLevel(currentPosition, currentBitmap);
        lastPosition = currentPosition;                              // remember this position just in case next print would be a (decimal) point or comma
        currentPosition++;
        if (currentPosition >= numDigits) currentPosition = 0;       // wrap around
      }
      strip.show();          // force strip.show() after each single write ... MISSING tbd if that's really a good idea, alternative: do it manually after the last print
      return 1;              // assume sucess
    }
};
