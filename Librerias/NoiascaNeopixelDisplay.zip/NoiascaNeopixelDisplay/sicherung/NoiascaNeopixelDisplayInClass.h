/* NoaiscaNeopixelDisplay
   Simulating a Seven Segment Display with Neopixels
   PROTOTYP - strip object in der Klasse machen

   noiasca
   2020-03-02 Erstversion: https://forum.arduino.cc/index.php?topic=668096.0
   2020-05-01 Mehrere Pixel pro Segment: https://forum.arduino.cc/index.php?topic=681417
   2020-05-02 letzte Änderung
*/

#pragma once
#define NOIASCA_NEOPIXEL_DISPLAY_VERSION "NoiascaNeopixelDisplay 0.0.1"  // this library
//#if defined(__AVR__)
//#include <avr/pgmspace.h>
//#elif defined(ESP8266)
//#include <pgmspace.h>
//#endif
#include <Adafruit_NeoPixel.h>                   // install library from Library manager

extern uint16_t addOffset(uint16_t position) __attribute__ ((weak));


/*
   Segments are named and orded like this

          SEG_A
   SEG_F         SEG_B
          SEG_G
   SEG_E         SEG_C
          SEG_D             SEG_DP

  The constants have to be defined in the user Sketch
  example:
  typedef uint32_t segsize_t;                                // also used in the library
  const segsize_t SEG_A  = 0b000000000000000000000111;
  const segsize_t SEG_B  = 0b000000000000000000111000;
  const segsize_t SEG_C  = 0b000000000000000111000000;
  const segsize_t SEG_D  = 0b000000000000111000000000;
  const segsize_t SEG_E  = 0b000000000111000000000000;
  const segsize_t SEG_F  = 0b000000111000000000000000;
  const segsize_t SEG_G  = 0b000111000000000000000000;
  const segsize_t SEG_DP = 0b000000000000000000000000;

*/


/* *******************************************************************
         Characterset for 7 segment
 * ******************************************************************/

const static segsize_t charTable [] PROGMEM  = {           // gekürzt auf Ziffern und ein paar Sonderzeichen, Rest kann aus dieser Library genommen werden: https://werner.rothschopf.net/201909_arduino_ht16k33.htm
  0,                                                       //     32   space
  SEG_B | SEG_C | SEG_DP,                                  // !   33
  SEG_B | SEG_F,                                           // "   34
  0,                                                       // #   35   not printable
  SEG_A | SEG_C | SEG_D | SEG_F | SEG_G,                   // $   36
  SEG_A | SEG_B | SEG_F | SEG_G,                           // %   37
  0,                                                       // &   38   not printable
  SEG_B,                                                   // '   39
  SEG_A | SEG_D | SEG_E | SEG_F,                           // (   40
  SEG_A | SEG_B | SEG_C | SEG_D,                           // )   41
  0,                                                       // *   42   not printable
  0,                                                       // +   43   not printable
  0,                                                       // ,   44   should be handled in the write methode
  SEG_G,                                                   // -   45
  0,                                                       // .   46   should be handled in the write methode
  SEG_B | SEG_E | SEG_G ,                                  // /   47
  SEG_A | SEG_B | SEG_C | SEG_D | SEG_E | SEG_F,           // 0   48
  SEG_B | SEG_C,                                           // 1   49
  SEG_A | SEG_B | SEG_D | SEG_E | SEG_G,                   // 2   50
  SEG_A | SEG_B | SEG_C | SEG_D | SEG_G,                   // 3   51
  SEG_B | SEG_C | SEG_F | SEG_G,                           // 4   52
  SEG_A | SEG_C | SEG_D | SEG_F | SEG_G,                   // 5   53
  SEG_A | SEG_C | SEG_D | SEG_E | SEG_F | SEG_G,           // 6   54
  SEG_A | SEG_B | SEG_C,                                   // 7   55
  SEG_A | SEG_B | SEG_C | SEG_D | SEG_E | SEG_F | SEG_G,   // 8   56
  SEG_A | SEG_B | SEG_C | SEG_D | SEG_F | SEG_G            // 9   57
};

const byte lastCharacter = 57;                             // if you expand the character set you have to adopt this variable

class NeoDisplay : public Print {
  private:
    const byte ledPin;                                     // Which pin on the Arduino is connected to the NeoPixels?
    const uint8_t numDigits;                               // digits per device
    const byte pixelPerDigit;                              // all Pixel,  include double point pixels if they are available at each digit
    const byte addPixels;                                  // unregular additional pixels to be added to the strip
    const byte segPerDigit = 7;                            // How many segments per digit (not implemented, has to be 7)
    const uint16_t ledCount;                               // How many NeoPixels are attached to the Arduino inkluding additional digits
    uint16_t currentPosition;                              // current position of cursor
    uint16_t lastPosition;                                 // last position of cursor - needed for dot and comma
    uint32_t colorFont = 0xFF0000;                         // default color of visible segment
    uint32_t colorBack = 0x000000;                         // default background color 0=black
    //segsize_t lastBitmap;                                // stores the last printed segments - for future use

    Adafruit_NeoPixel strip;

  public:
    NeoDisplay(byte ledPin, byte numDigits, byte pixelPerDigit, byte addPixels = 0):
      ledPin(ledPin),
      numDigits(numDigits),
      pixelPerDigit(pixelPerDigit),
      addPixels(addPixels),
      ledCount(pixelPerDigit * numDigits + addPixels),
      strip(ledCount, ledPin, NEO_GRB + NEO_KHZ800)
    {}

    void begin()
    {
      strip.begin();                   // INITIALIZE NeoPixel strip object (REQUIRED)
      strip.show();                    // Turn OFF all pixels ASAP
      strip.setBrightness(50);         // Set BRIGHTNESS to about 1/5 (max = 255)
    }

    void clear()
    {
      strip.clear();
      currentPosition = 0;
    }

    void setColorFont(uint32_t newColor)
    {
      colorFont = newColor;
    }

    void setCursor(uint16_t newPosition)
    {
      currentPosition = newPosition;
    }

    void setPixelColor(uint16_t n, uint32_t c)
    {
      strip.setPixelColor(n, c);
    }

    void show()
    {
      strip.show();
    }

    void writeLowLevel(uint8_t position, segsize_t bitmask, bool addOnly = false) {        // Ausgabe einer Bitmask an eine bestimmte Stelle
      byte offset = position * pixelPerDigit;                          // pixel offset = first pixel of this digit
      //uint16_t (*fun_ptr)(uint16_t) = &addOffset;
      if (addOffset)                                                   // only if available (adress doesn't point to NULL)
        offset = offset + addOffset(position);                         // the user can define his own ruleset for offset calculation due to additional pixels
      for (byte i = 0; i < pixelPerDigit * segPerDigit; i++)
      {
        if (bitmask & (1UL << i))
          strip.setPixelColor(i + offset, colorFont);
        else
          if (!addOnly) strip.setPixelColor(i + offset, colorBack);  
      }
    }

    size_t write(uint8_t value)
    {
      if (value == '.' || value == ',')
      {
         writeLowLevel(lastPosition, SEG_DP, true);                  // add decimal point to the last printed digit
      }
      else if (value > 31 && value < lastCharacter)                  // write printable ASCII characters to display
      {
        segsize_t currentBitmap;                                        // the current bitmap
        if (sizeof (segsize_t) == 1)
          currentBitmap = pgm_read_byte_near(charTable + value - 32);   // the table starts with the first printable character at 32
        else
          currentBitmap = pgm_read_word_near(charTable + value - 32);
        writeLowLevel(currentPosition, currentBitmap);
        lastPosition = currentPosition;                              // used in case of (decimal) point or comma
        currentPosition++;
        if (currentPosition >= numDigits) currentPosition = 0;       // wrap around
      }
      strip.show();          // force strip.show() after each single write ... MISSING ist das wirklich gut?
      return 1;              // assume sucess
    }
};